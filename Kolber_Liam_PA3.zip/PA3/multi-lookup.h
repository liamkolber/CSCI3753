#ifndef MULTI-LOOKUP_H_INCLUDED
#define MULTI-LOOKUP_H_INCLUDED

void *requester_entryFunction(void *);
void *resolver_entryFunction();

#endif
